
import { useState } from "react";
import API from "../services/api";

export default function BookForm({ reload }) {
  const [form, setForm] = useState({ title:"", author:"", email:"", age:"" });

  const change = e => setForm({...form, [e.target.name]: e.target.value});

  const submit = async e => {
    e.preventDefault();
    if(!form.title || !form.author) return alert("Fill all fields");
    await API.post("/", form);
    setForm({ title:"", author:"", email:"", age:"" });
    reload();
  };

  return (
    <form onSubmit={submit}>
      <input name="title" placeholder="Title" value={form.title} onChange={change}/>
      <input name="author" placeholder="Author" value={form.author} onChange={change}/>
      <input name="email" placeholder="Email" value={form.email} onChange={change}/>
      <input name="age" placeholder="Age" value={form.age} onChange={change}/>
      <button>Add</button>
    </form>
  );
}
