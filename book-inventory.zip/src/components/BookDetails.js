
import { useParams, Link } from "react-router-dom";
import { useEffect, useState } from "react";
import API from "../services/api";

export default function BookDetails() {
  const { id } = useParams();
  const [book, setBook] = useState({});

  useEffect(()=>{
    API.get(`/${id}`).then(r=>setBook(r.data));
  },[id]);

  return (
    <div>
      <h2>{book.title}</h2>
      <p>Author: {book.author}</p>
      <p>Email: {book.email}</p>
      <p>Age: {book.age}</p>
      <Link to="/">Back</Link>
    </div>
  );
}
