
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import API from "../services/api";
import BookForm from "./BookForm";

export default function BookTable() {
  const [books, setBooks] = useState([]);

  const load = async () => {
    const res = await API.get("/");
    setBooks(res.data);
  };

  useEffect(()=>{ load(); },[]);

  const remove = async id => {
    await API.delete(`/${id}`);
    load();
  };

  return (
    <div>
      <h2>Book Inventory</h2>
      <BookForm reload={load} />

      <div style={{maxHeight:"400px", overflowY:"auto"}}>
        <table>
          <thead>
            <tr><th>Title</th><th>Author</th><th>Actions</th></tr>
          </thead>
          <tbody>
            {books.map(b=>(
              <tr key={b.id}>
                <td><Link to={`/book/${b.id}`}>{b.title}</Link></td>
                <td>{b.author}</td>
                <td><button onClick={()=>remove(b.id)}>Delete</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
