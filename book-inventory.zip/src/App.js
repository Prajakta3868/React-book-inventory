
import { BrowserRouter, Routes, Route } from "react-router-dom";
import BookTable from "./components/BookTable";
import BookDetails from "./components/BookDetails";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<BookTable />} />
        <Route path="/book/:id" element={<BookDetails />} />
      </Routes>
    </BrowserRouter>
  );
}
